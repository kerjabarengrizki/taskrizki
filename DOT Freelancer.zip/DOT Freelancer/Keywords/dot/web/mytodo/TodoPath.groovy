package dot.web.mytodo

import dot.web.utility.CustomTestObject as CustomObject

public class TodoPath {

	public static final INPUT_TODO = CustomObject.getCSSTestObject("[placeholder='Create a new to-do...']")
	public static final EDIT_TODO = CustomObject.getXpathTestObject("(//input[@type='text'])[2]");
	public static final ICON_EDIT = CustomObject.getXpathTestObject("//li[1]//span[@class='fa fa-edit']")
	public static final ICON_DELETE = CustomObject.getXpathTestObject("//li[3]/button[@class='btn btn-outline-danger border-0']")
}
